function submitArchive(event)
{
    // only submit if email form is filled out
    if (document.getElementById('email').value == "") {
        $('#archive_results').text('You must fill out your email address for archive to work. Please click the "i" in the lower right hand corner to add your email');
        return;
    }
    // Get input from fields
    var archive_url = $('#archive_url').val();
    var email = $('#email').val();
    alert(archive_url);
    // Submit
    $.get("http://www.webcitation.org/archive", {url: archive_url, email: email, returnxml: "true"}, function (data, textStatus) {handleArchive(data, textStatus);}, "xml" );
    // Handle request
    function handleArchive(data, textStatus) {
        alert(archive_url);
        alert($(data).html());
        alert(textStatus);
        var status;
        var timestamp;
        var originalurl;
        var webciteurl;
        var archive;
        var authors = $('#authors').val();
        if ($('#authors').val() != "") authors += ". ";
        var title = $('#title').val();
        if ($('#title').val() != "") title += ". ";
        var source = $('#source').val();
        if ($('#source').val() != "") source += ". ";
        var publishdate = $('#publishdate').val();
        if ($('#publishdate').val() != "") publishdate += ". ";
        var d = new Date();
        var accessdate = "Accessed: " + d.getFullYear() + "-" + d.getMonth() + "-" + d.getDate() + ". ";
        // Parse returned XML
        $(data).find("result")
            .each(function() {
                var result = $(this);
                status = result.attr("status");
                timestamp = $(result).find("timestamp").text() + ". ";
                originalurl = $(result).find("original_url").text();
                webciteurl = $(result).find("webcite_url").text();
            });
        alert(timestamp);
        alert(originalurl);
        alert(webciteurl);
        alert(archive);
        // format plain text version
        plainarchive = authors+title+source+publishdate+'URL: '+originalurl+'. '+accessdate+'(Archived by WebCite® at '+webciteurl+')';
        // farmat html version
        htmlarchive = authors+title+source+publishdate+'URL: <a href="'+originalurl+'">'+originalurl+'</a>' + accessdate + "(Archived by WebCite&reg; at "+'<a href="'+webciteurl+'">'+webciteurl+'</a>)';
        // Display results & copy to clipboard
        if (document.getElementById('showhtml').checked == true) {
            $('#archive_results').text(htmlarchive); 
            copyToClip(htmlarchive);
            format = 2;
        } else {
            $('#archive_results').text(plainarchive);
            copyToClip(plainarchive);
            format = 1;
        }
    }
}
