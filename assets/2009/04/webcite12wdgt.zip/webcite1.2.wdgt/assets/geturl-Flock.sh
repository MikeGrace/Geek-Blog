#!/bin/sh
osascript<<END
tell application "Flock"
	set p to properties of front window as list
	return item 3 of p
end tell
END