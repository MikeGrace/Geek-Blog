#!/bin/sh
osascript<<END
tell application "Firefox"
	return «class curl» of front window
end tell
END