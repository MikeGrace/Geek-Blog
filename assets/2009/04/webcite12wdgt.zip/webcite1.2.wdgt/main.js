var plainarchive ='';
var htmlarchive = '';
function load()
{
    dashcode.setupParts();
    restoreSavedEmail();
    restoreSavedBrowser();
    restoreSavedResults();
    getURL();
}

function remove()
{
	// remove my instance preferences when remove from dashboard
	widget.setPreferenceForKey(null, "returnFormat");
	widget.setPreferenceForKey(null, "email");
	widget.setPreferenceForKey(null, "browser");
}

function hide(){}
function show(){}
function sync(){}

function showBack(event)
{
    var front = document.getElementById("front");
    var back = document.getElementById("back");
    if (window.widget) {
        widget.prepareForTransition("ToBack");
    }
    front.style.display = "none";
    back.style.display = "block";
    if (window.widget) {
        setTimeout('widget.performTransition();', 0);
    }
}

function showFront(event)
{
    
    var front = document.getElementById("front");
    var back = document.getElementById("back");
    if (window.widget) {
        widget.prepareForTransition("ToFront");
    }
    front.style.display="block";
    back.style.display="none";
    if (window.widget) {
        setTimeout('widget.performTransition();', 0);
    }
}

if (window.widget) {
    widget.onremove = remove;
    widget.onhide = hide;
    widget.onshow = show;
    widget.onsync = sync;
}

function submitArchive(event)
{
    // only submit if email form is filled out
    if (document.getElementById('email').value == "") {
        $('#archive_results').text('You must fill out your email address for archive to work. Please click the "i" in the lower right hand corner to add your email');
        return;
    }
    // Get input from fields
    var archive_url = $('#archive_url').val();
    var email = $('#email').val();
    // Submit
    $.get("http://www.webcitation.org/archive", {url: archive_url, email: email, returnxml: "true"}, function (data, textStatus) {handleArchive(data, textStatus);}, "xml" );
    // Handle request
    function handleArchive(data, textStatus) {
        var status;
        var timestamp;
        var originalurl;
        var webciteurl;
        var archive;
        var authors = $('#authors').val();
        if ($('#authors').val() != "") authors += ". ";
        var title = $('#title').val();
        if ($('#title').val() != "") title += ". ";
        var source = $('#source').val();
        if ($('#source').val() != "") source += ". ";
        var publishdate = $('#publishdate').val();
        if ($('#publishdate').val() != "") publishdate += ". ";
        var d = new Date();
        var accessdate = "Accessed: " + d.getFullYear() + "-" + d.getMonth() + "-" + d.getDate() + ". ";
        // Parse returned XML
        $(data).find("result")
            .each(function() {
                var result = $(this);
                status = result.attr("status");
                timestamp = $(result).find("timestamp").text() + ". ";
                originalurl = $(result).find("original_url").text();
                webciteurl = $(result).find("webcite_url").text();
            });
        // format plain text version
        plainarchive = authors+title+source+publishdate+'URL: '+originalurl+'. '+accessdate+'(Archived by WebCite® at '+webciteurl+')';
        // farmat html version
        htmlarchive = authors+title+source+publishdate+'URL: <a href="'+originalurl+'">'+originalurl+'</a>' + accessdate + "(Archived by WebCite&reg; at "+'<a href="'+webciteurl+'">'+webciteurl+'</a>)';
        // Display results & copy to clipboard
        if (document.getElementById('showhtml').checked == true) {
            $('#archive_results').text(htmlarchive); 
            copyToClip(htmlarchive);
            format = 2;
        } else {
            $('#archive_results').text(plainarchive);
            copyToClip(plainarchive);
            format = 1;
        }
    }
}

var browsers = ['Safari', 'Firefox', 'Camino', 'Opera', 'Flock', 'OmniWeb'];
var browser;
var format = 0;
function changeBrowser() {
    browser++;
    if (browser > 5){ browser = 0;}
    $('#button-browser img').attr('src', 'assets/icons/' + browsers[browser] + '.png');
    var check = widget.system('ps ax | grep -v grep | grep ' + browsers[browser] + '.app', null).outputString;
    if (check == undefined)
        document.getElementById('archive_url').value = 'http://';
    else 
        getURL();
}

function getURL(event) {
    var cmd;
    cmd = widget.system('assets/getURL-' + browsers[browser] + '.sh', null).outputString;
    cmd = cmd + "";
    if (cmd.match('top*'))
    {
        cmd = 'http://';
    }
    document.getElementById('archive_url').value = cmd;
    cmd = '';
}

function changeFormat(event)
{
    if (format == 1) {
        $('#archive_results').text(htmlarchive);
        copyToClip(htmlarchive);
        format = 2;
    }
    else if (format == 2) {
        $('#archive_results').text(plainarchive);
        copyToClip(plainarchive);
        format = 1;
    }
}

function copyToClip(text) {
    widget.system("/bin/echo -n '" + text + "' | /usr/bin/pbcopy", null);
}


document.onkeydown = KeyDownHandler;
emailFocus = false;
function KeyDownHandler(e)
{
    if (emailFocus)
    {
        var x = '';
        if (document.all)
        {
            var evnt = window.event;
            x = evnt.keyCode;
        }
        else
        {
            x = e.keyCode;
        }
        if (x == '13')
        {
            checkEmail();
        }
    }
}

function checkEmail()
{
    var email = $('#email').val();
    var re = '^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\\.[a-zA-Z]{2,4}$';
    if (email.match(re))
    {
        $('#invalidEmail').css("visibility","hidden");
        saveEmail(email);
        showFront();
    }
    else
    {
        $('#invalidEmail')
            .css("visibility","visible")
            .click(function () {
                saveEmail(email);
                $('#invalidEmail').css("visibility","hidden");
                showFront();    
            })
        ;

    }
}

function saveEmail(email)
{
    widget.setPreferenceForKey(email,"email");
}

function restoreSavedEmail()
{
    var savedEmail = widget.preferenceForKey("email");
    if (savedEmail)
        $('#email').val(savedEmail);
}


function setFocus(event)
{
    emailFocus = true;
}


function unsetFocus(event)
{
    emailFocus = false;
}

function saveBrowser(browser)
{
    widget.setPreferenceForKey(browser,"browser");
}

function changePrefBrowser()
{
    var savedBrowser = widget.preferenceForKey("browser");
    if (!savedBrowser) {savedBrowser = 0;}
    savedBrowser++;
    if (savedBrowser > 5) savedBrowser = 0;
    saveBrowser(browser);
    $('#prefBrowser img').attr('src', 'assets/icons/' + browsers[browser] + '.png');
    brower = savedBrowser;
}

function changeResults(event)
{
    if ($('#returnHTML').val() == "html")
    {
        $('#returnHTML').val("text").removeAttr("checked");
        $('#showhtml').removeAttr("checked");
        format = 2;
    }
    else
    {
        $('#returnHTML').val("html").attr("checked","checked");
        $('#showhtml').attr("checked","checked");
        format = 1;
    }
    widget.setPreferenceForKey($('#returnHTML').val(),"returnFormat");
}

function restoreSavedBrowser()
{
    var savedBrowser = widget.preferenceForKey("browser");
    if (savedBrowser)
    {
        browser = savedBrowser;
        $('#archive_results').html('');
    }
    else
    {
        browser = 0;
        saveBrowser(browser);
    }
    $('#button-browser img').attr('src', 'assets/icons/' + browsers[browser] + '.png');
    $('#prefBrowser img').attr('src', 'assets/icons/' + browsers[browser] + '.png');
}

function restoreSavedResults()
{
    var savedFormat = widget.preferenceForKey("returnFormat");
    if (savedFormat == "html")
    {
        $('#returnHTML').val("html").attr("checked","checked");
        $('#showhtml').attr("checked","checked");
        format = 2;
    }
    else
    {
        $('#returnHTML').val("text").removeAttr("checked");
        $('#showhtml').removeAttr("checked");
        format = 1;
    }
}























