#!/bin/sh
osascript<<END
tell application "Opera"
    return URL of front document as string
end tell
END