#!/bin/sh
osascript<<END
tell application "Camino"
    set p to properties of front tab of front window
    return |currentURI| of p as string
end tell
END