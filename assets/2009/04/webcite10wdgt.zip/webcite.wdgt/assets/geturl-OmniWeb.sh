#!/bin/sh
osascript<<END
tell application "OmniWeb"
	set gwi to GetWindowInfo
	return item 1 of gwi
end tell
END